package br.com.fiap;

import java.util.Scanner;

public class ExercícioAulaScanner {
//	public static void main(String[] args) {
//		float base = 0.0f, altura = 0.0f;
//		Scanner scan;
//		try {
//			scan = new Scanner(System.in);
//			System.out.println("Digite a base: ");
//			base = scan.nextFloat();
//			System.out.println("Digite a altura: ");
//			altura = scan.nextFloat();
//			System.out.println("Área do retângulo: " + (base * altura));
//		} catch (Exception e) {
//			System.out.println("Formato incorreto.");
//		}
//	}
//}

	
//	public static void main(String[] args) {
//		float base = 0.0f, altura = 0.0f;
//		Scanner scan;
//		try {
//			scan = new Scanner(System.in);
//			System.out.println("Digite a base: ");
//			base = scan.nextFloat();
//			System.out.println("Digite a altura: ");
//			altura = scan.nextFloat();
//			System.out.println("Área do triângulo: " + (base * altura) /2);
//		} catch (Exception e) {
//			System.out.println("Formato incorreto.");
//		}
//	}
//	}
	
//	public static void main(String[] args) {
//		float base1 = 0.0f, base2 = 0.0f, altura = 0.0f;
//		Scanner scan;
//		try {
//			scan = new Scanner(System.in);
//			System.out.println("Digite a base inferior: ");
//			base1 = scan.nextFloat();
//			System.out.println("Digite a base superior: ");
//			base2 = scan.nextFloat();
//			System.out.println("Digite a altura: ");
//			altura = scan.nextFloat();
//			System.out.println("Área do triângulo: " + ((base1+base2) * altura) /2);
//		} catch (Exception e) {
//			System.out.println("Formato incorreto.");
//		}
//	}
	
	
	
	
	public static void main(String[] args) {
		float A = 0.0f, B = 0.0f, C = 0.0f;
		Scanner scan;
		try {
			scan = new Scanner(System.in);
			System.out.println("Digite valor de A: ");
			A = scan.nextFloat();
			System.out.println("Digite o valor de B: ");
			B = scan.nextFloat();
			System.out.println("Digite o valor de C: ");
			C = scan.nextFloat();
			float delta = B*B - 4 * A * C;
			System.out.println("Resultado do X¹: " + (-B + Math.sqrt(delta)) / (2 * A));
			System.out.println("Resultado do X²: " + (-B - Math.sqrt(delta)) / (2 * A));
		} catch (Exception e) {
			System.out.println("Formato inválido.");
	

	}
	}
}