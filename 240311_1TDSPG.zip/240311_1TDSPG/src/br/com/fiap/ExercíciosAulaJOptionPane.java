package br.com.fiap;

import javax.swing.JOptionPane;

public class ExercíciosAulaJOptionPane {
	public static void main(String[] args) {
		float base = 0.0f, altura = 0.0f;
		String aux;
		try {
			aux = JOptionPane.showInputDialog("Digite o valor da base:");
			base = Integer.parseInt(aux);
			aux = JOptionPane.showInputDialog("Digite o valor da altura: ");
			altura = Integer.parseInt(aux);
			JOptionPane.showMessageDialog(null, "A área do retângulo é: " + (base * altura));
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Formato incorreto.");
		}
	}
}
